<?php

class DB{
    protected $db;

    public function __construct(){
        $this->db=mysqli_connect("localhost","root","","std");
    }
    public function getConn(){
        if($this->db){
            return $this->db;
        }else{
            return "error";
        }
    }
 
} 

?>