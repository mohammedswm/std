 <?php

require "db.php";

class User extends DB{
   
    private $user_db;
    
    public function connection(){
        $this->user_db=$this->db;
        if(!$this->user_db){
            echo "error";
        }else{
        echo"ok";
    }}
    //select Colloge
    public function selectColloge(){
       $qury = "SELECT collageID,CollageName
                from collage
                order by collageID";
       $mysql = mysqli_query($this->user_db,$qury);
       if($mysql->num_rows > 0){
        while($row= mysqli_fetch_assoc($mysql))
        {
            echo '<option value="'.$row['collageID'].'" > '.$row['CollageName'].' </option>';
        }
    }else {
        echo mysqli_error();
    }}
  /////////////////////////////////////////////////////////  // end select Colloge
     public function selectTotalhourLac($id){
        
        $qury = "SELECT sum(CR) as l 
                 FROM `courses`
                 WHERE `courseLevel`= ".$id.""; 
        $mysql = mysqli_query($this->user_db,$qury);
        if($mysql->num_rows > 0){
         while($row= mysqli_fetch_assoc($mysql))
         {
          return $row['l'] ;
                                                
         }
     }else {
         echo mysqli_error();
     }} 
   // select selectAjax
    public function selectAjaxDepartment($id){
        $qury = "SELECT  depID, depName
                 from dep  
                 where collageID = ".$id.""; 
        $mysql = mysqli_query($this->user_db,$qury);
        if($mysql->num_rows > 0){
         while($row= mysqli_fetch_assoc($mysql))
         {
            echo '<option value='.$row['depID'].' > '.$row['depName'].' </option>'; 
         }
        }else {
            echo '<option  > القسم </option>'; 
        echo mysqli_error();
       }}
    

    public function selectAjaxLevel($id){
        $qury = "SELECT DISTINCT `courseLevel` 
                FROM `courses`
                WHERE `depID`= ".$id.""; 
        $mysql = mysqli_query($this->user_db,$qury);
        if($mysql->num_rows > 0){
         while($row= mysqli_fetch_assoc($mysql))
         {
            echo '<option value='.$row['courseLevel'].' > '.$row['courseLevel'].' </option>'; 
          
         }
        }else {
            echo '<option  > القسم </option>'; 
        echo mysqli_error();
       }}

   
       
    }   


//print test for connection
$dbClass = new User ();
$dbClass->connection();

// call ajax selectAjaxDepartment 
if( isset($_POST['collageID'] )){
    $id = $_POST['collageID'];
    $dbClass->selectAjaxDepartment($id);  
}

if( isset($_POST['depID'] )){
    $id = $_POST['depID'];
    $dbClass->selectAjaxLevel($id);  
}
////////////////////////////////////////////////////////////////////////////
if( isset($_POST['courseLevel'] )){
    $id = $_POST['courseLevel'];
    $dbClass->selectTotalhourLac($id);  
}
    

 
 
