<?php 
include 'connaction.php';

?>
<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <meta name="viewport" , content="width-device-width,intial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="description" content="An interactive getting started guide for Brackets.">
    <title>الرئيسية</title>
    
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="styletest.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
</head>

<body>
    <div class="container-fluid">
        <!--البلوك 1-->
        <div class="row">
            <div class="col topDiv">
                <label>جدولة المقررات</label>
            </div>
        </div>

        <!--البلوك 2-->
        <div class="row ">
            <div class="col-xs-3 col-md-6">
        
                <div class="row block3">
                    <div class="col-xs-5 col-md-6">
                        
                        <select  id="coll" class="form-select" >
                        <option value='0'> الكلية </option>
                        <?php 
                         $dbr =$dbClass->selectColloge();
                        ?>
                        </select>
                    </div>

                    <div class="col-xs-5 col-md-6">
                        <select  id="dep" class="form-select" >
                       <option value='0'> القسم </option>
                       
                        </select>
                       
                    </div>
                </div>

                <!--البلوك 3-->

                <!--1-3 البلوك -->
                <div class="row block3">
                    <div class="col">
                        المقرر معروض
                        <input class="form-check-input" name="flexRadioDefault" id="" type="radio" value="">
                        <label class="form-check-label">للطلاب</label>
                        <input class="form-check-input" name="flexRadioDefault" id="" type="radio" value="">
                        <label class="form-check-label">للطالبات</label>
                    </div>
                </div>

                <!--2-3 البلوك -->
                <div class="row block3">
                    <div class="col">
                        المقررات المعروضة
                        <input type="radio" class="form-check-input" id="" value="">
                        <label class="form-check-label">حسب الخطة</label>
                        <input type="radio" class="form-check-input" id="" value="">
                        <label class="form-check-label">خارج الخطة</label>
                    </div>
                </div>

                <!--3-3 البلوك -->
                <div class="row block3">
                    <div class="col">
                        <label class="form-check-label">الفصل الدراسي</label>
                        <input type="radio" class="form-check-input" id="" value="">
                        <label class="form-check-label"> الأول</label>
                        <input type="radio" class="form-check-input" id="" value="">
                        <label class="form-check-label"> الثاني</label>
                        <input type="radio" class="form-check-input" id="" value="">
                        <label class="form-check-label"> الصيفي</label>
                    </div>
                </div>

                <!--4-3 البلوك -->
                <div class="row block3">
                    <div class="col-xs-2 col-md-12">
                        <div class="table-responsive">
                            <table id="">
                                <tr>
                                    <th> <label class="form-label" style="width: 100px">المستوى</label></th>
                                    <th> <label class="form-label" style="width: 70px">المعتمد</label></th>
                                    <th><label class="form-label" style="width: 70px"> العملي</label></th>
                                    <th><label class="form-label" style="width: 70px"> النظري</label> </th>
                                </tr>
                                <tr>
                                    <td><select  id="level" name="levelw" class="form-select" >
                                        <option value='0'> المستوى </option>
                                        </select></td>
                                    <td><input id="totalLec" name="totalLec"class="form-control tin" type="text" value="">
                                    <?php
                                     
                                   ?>
                                      
                                    </td>
                                    <td> <input class="form-control tin" type="text"></td>
                                    <td> <input class="form-control tin" type="text"></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

                <!--5-3 البلوك -->
                <div class="row block3">
                    <div class="col-xs-2 col-md-12">
                        <label class="form-label">الشعبة</label>
                        <input type="text" class="form-control tin1" style="width: 150px;">
                    </div>
                </div>
                <!--4-3البلوك -->
                <div class="row block3 ">
                    <div class="col-xs-2">
                        <div class="table-responsive">
                            <table class="" id="">
                                <tr>
                                    <th style="width: 75px">رمز المادة</th>
                                    <th style="width: 300px">اسم المادة</th>
                                    <th style="width: 51px">(نظري)</th>
                                    <th style="width: 51px">(عملي)</th>
                                </tr>
                                <tr>
                                    <td><select style="width: 75px" class="form-select"></select></td>
                                    <td><input style="width: 300px" class="form-control"></td>
                                    <td><input id="inpuLec" style="width: 51px" class="form-control"></td>
                                    <td><input id="inputlab"style="width: 51px" class="form-control s"></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <!--5-3البلوك -->
                <div class="row block3 ">
                    <div class="col-xs-2">
                        <div class="table-responsive">
                            <table id="itemsTable" class="hidenLab">
                                <tr>
                                    <th style="width: 91px">نوع</th>
                                    <th style="width: 51px">الأيام</th>
                                    <th style="width: 95px">عدد الساعات</th>
                                    <th style="width: 51px">بداية</th>
                                    <th style="width: 51px">النهاية</th>

                                    <th style="width: 61px">القاعة</th>
                                </tr>
                                <tr class="v">
                                    <td><select class="form-select" style="width: 91px">
                                            <option style="width: 91px">نظري</option>
                                            <option style="width: 91px">عملي</option>
                                        </select>
                                    </td>
                                    <td><select class="form-select" style="width: 51px"></select></td>
                                    <td><select class="form-select" style="width: 95px"></select></td>
                                    <td><input class="form-control" style="width: 51px"></td>
                                    <td><input class="form-control" style="width: 51px"></td>

                                    <td><input class="form-control" style="width: 60px"></td>
                                    <td><input id="add" class="form-control btnMoreMate" type="button" name="add"
                                            value=" المزيد">
                                        <!--  <button type="button" onclick="myFunction()">Try it</button>-->
                                    </td>

                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="col-xs-2">
                        <div class="table-responsive">
                            <table class="hidenLab">
                                <tr>
                                    <th style="width: 91px">رقم الهوية </th>
                                    <th style="width: 200px">اسم المعلم</th>
                                </tr>
                                <tr>
                                    <td><input class="form-control" style="width: 91px"></td>
                                    <td><input class="form-control" style="width: 200px"></td>
                                    <td><a href="addIns.html">
                                            <button class="btn btn-dark"> طلب معلم من كلية أخرى</button>

                                </tr>
                            </table>
                        </div>
                    </div>

                </div>
               <!--6-3البلوك -->
                <div id="hiden" class="row block3 ">
                    <div class="col-xs-2">
                        <div class="table-responsive">
                            </table>
                            <table id="itemsTable1" class="hidenLec ">
                                <tr>
                                    <th style="width: 91px">نوع</th>
                                    <th style="width: 51px">الأيام</th>
                                    <th style="width: 95px">عدد الساعات</th>
                                    <th style="width: 51px">بداية</th>
                                    <th style="width: 51px">النهاية</th>

                                    <th style="width: 61px">القاعة</th>
                                </tr>
                                <tr class="v">
                                    <td><select class="form-select" style="width: 91px">
                                            <option style="width: 91px">نظري</option>
                                            <option style="width: 91px">عملي</option>
                                        </select>
                                    </td>
                                    <td><select class="form-select" style="width: 51px"></select></td>
                                    <td><select class="form-select" style="width: 95px"></select></td>
                                    <td><input class="form-control" style="width: 51px"></td>
                                    <td><input class="form-control" style="width: 51px"></td>

                                    <td><input class="form-control" style="width: 60px"></td>
                                    <td><input id="add1" class="form-control btnMoreMate" type="button" name="add"
                                            value=" المزيد">
                                        <!--  <button type="button" onclick="myFunction()">Try it</button>-->
                                    </td>

                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="col-xs-2">
                        <div class="table-responsive">
                            <table class="hidenLec">
                                <tr>
                                    <th style="width: 91px">رقم الهوية </th>
                                    <th style="width: 200px">اسم المعلم</th>
                                </tr>
                                <tr>
                                    <td><input class="form-control" style="width: 91px"></td>
                                    <td><input class="form-control" style="width: 200px"></td>
                                    <td><a href="addIns.html">
                                            <button class="btn btn-dark"> طلب معلم من كلية أخرى</button>
                                </tr>
                            </table>
                        </div>
                    </div>
                    </div>
                            <div class="row block3">
                                <div class="col">
                                    <table>
                                <tr>
                                    <td colspan="4"></a><button class="btn btn-dark">حفظ</button></td>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

            </div>



            <!--البلوك 4-->
            <div class="col-xs-9 col-md-6">
                <div class="row">
                    <div class="col">
                        <table class="" id="itemsTable">
                            <tr>
                                <th colspan="3" class="table-active" style="display: grid; box-shadow:none"> <a
                                        href="table.html">
                                        <button class="btn btn-dark">استعراض الجدول</button></a>
                                </th>
                                <th style="width: 75px">رمز المادة</th>
                                <th style="width: 300px">اسم المادة</th>
                                <th style="width: 51px">الشعب</th>
                            </tr>
                            <!--  delete it -->
                            <tr>
                                <td style="width: 75px">رمز المادة</td>
                                <td style="width: 300px">اسم المادة</td>
                                <td style="width: 51px">الشعب</td>
                            </tr>
                            <tr>
                                <td style="width: 75px">رمز المادة</td>
                                <td style="width: 300px">اسم المادة</td>
                                <td style="width: 51px">الشعب</td>
                            </tr>
                            <tr>
                                <td style="width: 75px">رمز المادة</td>
                                <td style="width: 300px">اسم المادة</td>
                                <td style="width: 51px">الشعب</td>
                            </tr>
                            <tr>
                                <td style="width: 75px">رمز المادة</td>
                                <td style="width: 300px">اسم المادة</td>
                                <td style="width: 51px">الشعب</td>
                            </tr>
                            <tr>
                                <td style="width: 75px">رمز المادة</td>
                                <td style="width: 300px">اسم المادة</td>
                                <td style="width: 51px">الشعب</td>
                            </tr>
                            <tr>
                                <td style="width: 75px">رمز المادة</td>
                                <td style="width: 300px">اسم المادة</td>
                                <td style="width: 51px">الشعب</td>
                            </tr>
                            <tr>
                                <td style="width: 75px">رمز المادة</td>
                                <td style="width: 300px">اسم المادة</td>
                                <td style="width: 51px">الشعب</td>
                            </tr>
                            <!--  delete it    -->
                        </table>
                    </div>
                </div>


            </div>
        </div>



</body>
<script>
    
    $(document).ready(function () {
        /*
        $('#coll').on('change', function(){
        var countryID = $(this).val();
        //alert(countryID);
        if(countryID){
           // alert(countryID);
            $.ajax({
                type:'POST',
                url:'connaction.php',
                data:'CollageID='+countryID,
                success:function(html){
                    $('#dep').html(html);
                   
                }
            }); 
        }else{
            $('#dep').html('<option value="">Select country first</option>');
           
        }
    }); */
        // colloge select
        $('#coll').on('change',function(){
         var collID = $(this).val();
        alert(collID);
         if(collID){
          $.ajax({
           type:"POST",
           url:"connaction.php",
          // data:{campuID:campuID},
           data:'collageID='+collID,
           datatype:"html",
           success:function(data){
             $('#dep').html(data);  
            //alert (data);  
           }
         });
         }else{
           $('#dep').html('<option>ggg</option>');
         }
       });

       $('#dep').on('change',function(){
         var campuID = $(this).val();
        alert(campuID);
         if(campuID){
          $.ajax({
           type:"POST",
           url:"connaction.php",
          // data:{campuID:campuID},
           data:'depID='+campuID,
           datatype:"html",
           success:function(data){
             $('#level').html(data);
            // $('#totalLec').html(data);  
            //alert (data);  
           }
         });
         }else{
           $('#level').html('<option>ggg</option>');
         }
       });

       $('#level').on('change',function(){
         var campuID = $(this).val();
        alert(campuID);
         if(campuID){
          $.ajax({
           type:"POST",
           url:"connaction.php",
          // data:{campuID:campuID},
           data:'courseLevel='+campuID,
           datatype:"html",
           success:function(data){
             $('#totalLec').html(data);
            // $('#totalLec').html(data);  
            //alert (data);  
           }
         });
         }else{
           $('#level').html('<option>ggg</option>');
         }
       });
      

    
           // hide div
         var input1s = "";
        //input LEC
        $("#inpuLec").change(function () {
            input1s = $(this).val();
            if (input1s <= 0) {
                // $("#d").html(input1s);
                $(".hidenLec").hide();

            } else {
                $(".hidenLec").show();
            }
      
        }).change(); 
        $("#inputlab").change(function () {
            input1s = $(this).val();
            if (input1s <= 0) {
                // $("#d").html(input1s);
                $(".hidenLab").hide();

            } else {
                $(".hidenLab").show();
            }
        }).change();    

        $(document).on('click', '#add', function () {

            var htm1 = '';
            htm1 += '<tr>';
            htm1 += '<td><select class="form-select" style="width: 91px"><option style="width: 91px">نظري</option><option style="width: 91px">عملي</option> </select></td>';
            htm1 += '<td><select class="form-select" style="width: 51px"></select></td>';
            htm1 += '<td><select class="form-select" style="width: 95px"></select></td>';
            htm1 += '<td><input class="form-control" style="width: 51px"></td>';
            htm1 += '<td><input class="form-control" style="width: 51px"></td>;';
            htm1 += '<td><input class="form-control" style="width: 60px"></td>';
            htm1 += '<td><input class="form-control btnMoreMate" type="button" id="remove" name="remove" value="حذف"></td></tr>';





            //$('#itemsTable').append(htm1);
            $('#itemsTable').append(htm1);
        });
        $(document).on('click', '#add1', function () {
            var htm1 = '';
            htm1 += '<tr>';
            htm1 += '<td><select class="form-select" style="width: 91px"><option style="width: 91px">نظري</option><option style="width: 91px">عملي</option> </select></td>';
            htm1 += '<td><select class="form-select" style="width: 51px"></select></td>';
            htm1 += '<td><select class="form-select" style="width: 95px"></select></td>';
            htm1 += '<td><input class="form-control" style="width: 51px"></td>';
            htm1 += '<td><input class="form-control" style="width: 51px"></td>;';
            htm1 += '<td><input class="form-control" style="width: 60px"></td>';
            htm1 += '<td><input class="form-control btnMoreMate" type="button" id="remove" name="remove" value="حذف"></td></tr>';





            //$('#itemsTable').append(htm1);
            $('#itemsTable1').append(htm1);
        });

        $(document).on('click', "#remove", function () {
            $(this).closest('tr').remove();
        });
    });

</script>